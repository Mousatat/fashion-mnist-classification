import pytorch_lightning as pl

from datamodules import Datamodules

import hydra

from omegaconf import DictConfig

from pytorch_lightning_model import Classifier

@hydra.main(config_path="conf", config_name="config")
def train(cfg: DictConfig):
    data_module = Datamodules(batch_size=cfg.batch_size)
    model = Classifier(lr=cfg.lr, optimizer=cfg.optimizer)
    trainer = pl.Trainer(max_epochs=cfg.epochs)
    trainer.fit(model, data_module) 
if __name__ == '__main__':
    train()