import torch
from torch import optim, nn
import pytorch_lightning as pl


class Classifier(pl.LightningModule):
    def __init__(self, lr, optimizer):
        super().__init__()
        self.fc1=nn.Linear(784, 128)
        self.relu1=nn.ReLU()
        self.drop1=nn.Dropout(0.25)
        self.fc2=nn.Linear(128, 64)
        self.relu2=nn.ReLU()
        self.drop2=nn.Dropout(0.25)
        self.output=nn.Linear(64, 10)
        self.log_softmax=nn.LogSoftmax(dim=1)
        self.lr=lr
        self.optimizer=optimizer
    def forward(self, V):
        V = V.view(V.size(0), -1)
        V = self.fc1(V)
        V = self.relu1(V)
        V = self.drop1(V)
        V = self.fc2(V)
        V = self.relu2(V)
        V = self.drop2(V)
        V = self.output(V)
        V = self.log_softmax(V)
        return V
    def training_step(self, batch , batch_index):
        x , y = batch
        Y = self(x)
        loss_function = nn.functional.nll_loss(Y,y)
        self.log('train_loss',loss_function)
        return loss_function

    def validation_step(self, batch, batch_index):
        x , y = batch
        Y = self(x)
        loss_function = nn.functional.nll_loss(Y,y)
        self.log('val_loss',loss_function)
        return loss_function

    def test_step(self, batch, batch_index):
        x , y = batch
        Y = self(x)
        loss_function = nn.functional.nll_loss(Y,y)
        self.log('test_loss',loss_function)
    def configure_optimizers(self):
        if self.optimizer =='sgd':
            The_optimizer = optim.SGD(self.parameters(), lr=self.lr)
        elif self.optimizer =='adam':
            The_optimizer = optim.Adam(self.parameters(), lr=self.lr)
        else:
            raise ValueError("probably The optimizer is Unsupported")
        return The_optimizer
    
    