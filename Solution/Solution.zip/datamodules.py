import torch
from torch.utils.data import random_split, DataLoader
import torchvision.transforms as transforms
import pytorch_lightning as pl 
from torchvision.datasets import FashionMNIST

class Datamodules(pl.LightningDataModule):
    def __init__(self, path: str = './data', batch_size: int = 64):
        super().__init__()
        self.path = path
        self.batch_size = batch_size
        self.transform_pipline = transforms.Compose([transforms.ToTensor(),transforms.Normalize((0.5,), (0.5,))])

    def prepare(self):
        # this section to avoid downloading every time we split the dataset
        FashionMNIST(self.path, train=True, download=True)
        FashionMNIST(self.path, train=False, download=True)
    def setup(self,stage= None):
        # I will take the validate dataset from the train section of the dataset
        dataset =   FashionMNIST(self.path, train=True, download=True,transform=self.transform_pipline)
        train_len = (0.8*len(dataset))
        train_len =int(train_len)
        validate_len = len(dataset) - train_len
        self.train, self.val = random_split(dataset, [train_len,validate_len])
        self.test = FashionMNIST(self.path, train=False, download=True,transform=self.transform_pipline)

    def train_dataloader(self):
        return  DataLoader(self.train, batch_size=self.batch_size, num_workers=torch.get_num_threads())
    def val_dataloader(self):
        return  DataLoader(self.test, batch_size=self.batch_size, num_workers=torch.get_num_threads())
    def test_dataloader(self):
        return  DataLoader(self.val, batch_size=self.batch_size, num_workers=torch.get_num_threads())
    